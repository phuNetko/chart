import CanvasJSReact from '@canvasjs/react-charts';
var CanvasJSChart = CanvasJSReact.CanvasJSChart;
interface DataPoint {
    label: string;
    y: number;
    percentage?: number;
    color?: string
}
export default function Pyramid({data}:{data:any}) {
    const MIN_HEIGHT = 30; 
    const adjustDataPoints = (dataPoints: DataPoint[]): DataPoint[] => {
        const total = dataPoints.reduce((sum, dp) => sum + dp.y, 0);
        return dataPoints.map(dp => ({
            ...dp,
            y: Math.max(dp.y, (dp.y / total) < (MIN_HEIGHT / 100) ? (total * MIN_HEIGHT / 100) : dp.y),
        }));
    };
    const dataPoints: DataPoint[] = adjustDataPoints([
        { label: "Impressions", y: data.data1, color: '' },
        { label: "Clicked", y: data.data2, color: '' },
        { label: "Free Downloads", y: data.data3, color: '' },
    ]);
    const options = {
        animationEnabled: false,
        title: {
            // text: "Sales via Advertisement"
        },
        toolTip: {
            enabled: false,
        },
        data: [{
            type: "pyramid",
            showInLegend: false,
            indexLabel: `{y}`,
            indexLabelPlacement: "inside",
            indexLabelFontSize: 16,
            indexLabelFontStyle: "bold",
            dataPoints: dataPoints
        }],
        width: 288
    };
    return (
        <div className='w-[250px] mx-[-1px] chart_pyramid_container flex  justify-center'>
            <CanvasJSChart options={options} />
        </div>
    );
}
