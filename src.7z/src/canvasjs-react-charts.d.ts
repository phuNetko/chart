// canvasjs-react-charts.d.ts
declare module '@canvasjs/react-charts' {
    const CanvasJSChart: React.ComponentType<any>;
    export { CanvasJSChart };
}
