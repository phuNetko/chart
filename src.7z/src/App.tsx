
import './App.css'
import LineChart from './components/charts/lineChart'
import Pyramid from './components/charts/pyramid'
import StackedBar from './components/charts/stackedbar'

function App() {
  return (
    <div className='flex flex-col gap-4'>
      <div className='flex flex-row'>
        <Pyramid data={{
          data1: 30,
          data2: 20,
          data3: 10
        }} />
        <Pyramid data={{
          data1: 30,
          data2: 50,
          data3: 20
        }} />
        <Pyramid data={{
          data1: 50,
          data2: 60,
          data3: 20
        }} />
      </div>
      <div className='flex flex-row gap-4'>
        <StackedBar />
        <StackedBar />
      </div>
      <div className='flex flex-col w-[500px] overflow-x-auto'>
        <LineChart />
        <LineChart />
      </div>
    </div>
  )
}

export default App
